Cosmic Clones v1.0
By lx5

This sprite creates a Cosmic Clone that follows the same path as Mario followed in the previous frames, it evens imitates some of Mario's poses!

Feel free to report bugs by creating issues in this github repo.