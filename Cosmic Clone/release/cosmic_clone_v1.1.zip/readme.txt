Cosmic Clones v1.1
By lx5

This sprite creates a Cosmic Clone that follows the same path as Mario followed in the previous frames, it evens imitates some of Mario's poses!

Feel free to report bugs by creating issues in this github repo. Be sure to know how to use PIXI and UberASM before reporting bugs!

Changelog.

v1.1
- Cosmic Clones no longer utilizes GFX32 and GFX00 for their graphics.
- Cosmic Clones can now have their own custom graphics.
- It's possible to have different palettes,  disable the small cloud trail and disable drawing the 8x8 tiles on each Cosmic Clone.

v1.0 
- Initial release.